#include "datetimedialog.h"
#include "ui_datetimedialog.h"

DateTimeDialog::DateTimeDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::DateTimeDialog)
{
    ui->setupUi(this);
}

DateTimeDialog::~DateTimeDialog()
{
    delete ui;
}


// 月份牌选择改变槽函数
void DateTimeDialog::on_m_calendar_selectionChanged()
{

}

// text() - setText()
// 获取按钮槽函数
// dateTime.date() - 日期对象
void DateTimeDialog::on_m_btnGet_clicked()
{
    // 获取当前日期时间
    QDateTime dateTime = QDateTime::currentDateTime();

    ui->m_dateEdit->setDate( dateTime.date());
    ui->m_timeEdit->setTime( dateTime.time());
    ui->m_datetimeEdit->setDateTime(dateTime);

    // 当前的日期/时间/日期时间转换为字符串
    // 将对应的字符串放到右边的lineEdit中
}

// 设置按钮槽函数
void DateTimeDialog::on_m_btnSet_clicked()
{

}
